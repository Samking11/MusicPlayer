enum Playback {
  repeatSong,
  shuffle,
}
