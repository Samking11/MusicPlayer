//Flutter version 1.7.8+hotfix.4

import 'package:flutter/material.dart';
import 'package:music_app/src/root.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChillifyApp());
}
